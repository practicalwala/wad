npm install -g @angular/cli

ng serve
